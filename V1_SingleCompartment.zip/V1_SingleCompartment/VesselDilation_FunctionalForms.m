% vessel dilation

% %Arteriole resistance Huppert et al. 2007 % a single compartment, actively
% %dilating with resistance
% t=0.01:0.01:8;
% DeltaRA=0.05;
% sigma_R=1.5; %s
% tau_peak=3;%s
% RAt_ratio=1-DeltaRA/sqrt(sigma_R^2*pi)*exp(-(t-tau_peak).^2/sigma_R^2).*t.^2; %
% %
% %RAt_ratio=1-t.*exp(-(t-tau_peak));
% subplot(3,1,1)
% plot(t,RAt_ratio)
% xlabel('t (s)')
% ylabel('rR')
% 
% %% arteriole, active compartments
% subplot(3,1,2)
% rCBV=sqrt(1./RAt_ratio); % V ~ D^2, resistance ~1/D^4;
% plot(t,rCBV)
% xlabel('t (s)')
% ylabel('rCBV')
% 
% %% CBF  assumed to be the same for art and venous compartments
% subplot(3,1,3)
% rCBF=1./RAt_ratio; % assume the pressure difference is constant for the arteriole compartment 
% %rCBF
% plot(t,rCBF)
% xlabel('t (s)')
% ylabel(' rCBF')
% % venous compartment
% %% compliance
% % figure
% % alpha=0.38; % grubb relation
% % rCBV_venous=rCBF.^(1/alpha);
% % plot(t,rCBV_venous)
% % xlabel('t (s)')
% % ylabel(' Venous rCBV')

%% Vessel dilation model 

t=0:0.01:15;
deltaD=0.05;
sigma_D=1.83;

rD=1+t.^2*deltaD.*exp(-t.^2/sigma_D^2);





% subplot(3,1,1)
% plot(t,rD)
% xlabel('t (s)')
% ylabel('rD')

%  subplot(3,1,2)
 rCBV=rD.^2; % assume the pressure difference is constant for the arteriole compartment 
% %rCBF
%  plot(t,rCBV)
%  xlabel('t (s)')
%  ylabel('rCBV')
 
 
 %subplot(3,1,3)
  rCBF=rCBV.^2;
% 
%  plot(t,rCBF)
%  xlabel('t (s)')
%  ylabel('rCBF')
