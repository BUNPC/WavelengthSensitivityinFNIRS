% the main program 
clc
clear

lambdaall=650:10:900;
for nn=1:length(lambdaall)
lambda=lambdaall(nn); %nm
HbO=60*10^(-6); %M
HbR=40*10^(-6); %M

musp=CalculateMusp(lambda); %mm^(-1)
ext=GetExtinctions(lambda); % cm-1/(moles/liter)

mua=(ext(1)*HbO+ext(2)*HbR)*10^(-1); %mm^(-1)
%% activation 
r_source=[0,0,0]; % source position, units mm
r_det=[30,0,0]; %detector position
S=1; % source amplitude 
voxelsize=1; % mm^3
Radius_activation=3;
r_act=[15 0 10];
%%
VesselDilation_FunctionalForms; % we have t, rCBF, rCBV generated

rCMRO2=rCBF.^(1/3);
HbT_act=rCBV*(HbO+HbR);
rHbR=rCMRO2./rCBF.*rCBV;
HbR_act=rHbR*HbR;
HbO_act=HbT_act-HbR_act;

delta_mua=(ext(1)*HbO_act+ext(2)*HbR_act)*10^(-1)-mua;


%%

% nn=0;
% for delta_mua=0:0.00001:0.001% mm^(-1)

for tt=1:length(delta_mua)
Phi(tt)=CalculatePhi(r_source,r_det,musp,mua,delta_mua(tt),r_act,Radius_activation,S, voxelsize);

end

% plot(t,Phi)
% 
% 
% subplot(4,1,1)
% plot(t,HbR_act)
%  xlabel('t (s)')
%  ylabel('HbR (\muM)')
%  
%  subplot(4,1,2)
% plot(t,HbO_act)
%  xlabel('t (s)')
%  ylabel('HbO (\muM)')
%   subplot(4,1,3)
% plot(t,HbR_act+HbO_act)
%  xlabel('t (s)')
%  ylabel('HbT (\muM)')
%  subplot(4,1,4)
%  plot(t,Phi/Phi(1))
%   xlabel('t (s)')
%  ylabel('\phi/\phi_0')
%  
 
 Phiall(nn,:)=Phi/Phi(1);
end

figure
imagesc(t,lambdaall,Phiall-1); caxis([-0.025 0.025]);
xlabel('t (s)')
ylabel('\lambda (nm)')
colorbar
title('\Delta\Phi(\lambda,t)/\Phi_0')
set(gcf, 'unit', 'inches')
set(gcf, 'position',[1,1,4,3])
set(gca,'fontsize', 12);


% figure
% [X,Y]=meshgrid(t,lambdaall);
% surf(X,Y,Phiall,'EdgeColor','none')
% xlabel('t (s)')
% ylabel('\lambda (nm)')
% zlabel('\Phi/Phi_0')

% figure
% plot(lambdaall,Phiall(:,1826))
% xlabel('\lambda (nm)')
% ylabel('\Phi/\Phi_0')
% % end
% 
% plot(0:0.00001:0.001,Phi);
% xlabel('\delta\mu_a mm^{-1}')
% ylabel('\Phi')