%% plot the figures 
clc
clear
lambdaall=650:10:900;

%% musp
for ii=1:length(lambdaall)
muspall(ii)=CalculateMusp(lambdaall(ii)); 
end

plot(lambdaall,muspall)
xlabel('\lambda (nm)')
ylabel('\mu_s'' (mm^{-1})')

%%
eall = GetExtinctions(lambdaall);
subplot(2,1,1)
plot(lambdaall,eall(:,1));
xlabel('\lambda (nm)')
ylabel('\epsilon_{HbO} (cm^{-1}M^{-1})')

subplot(2,1,2)
plot(lambdaall,eall(:,2));
xlabel('\lambda (nm)')
ylabel('\epsilon_{HbR} (cm^{-1}M^{-1})')

%% mua

 % cm-1/(moles/liter)
HbO=60*10^(-6); %M
HbR=40*10^(-6); %M
%mua=(ext(1)*HbO+ext(2)*HbR)*10^(-1); %mm^(-1)
for ii=1:length(lambdaall)
    ext=GetExtinctions(lambdaall(ii));
muaall(ii)=(ext(1)*HbO+ext(2)*HbR)*10^(-1); 
end

plot(lambdaall,muaall)
xlabel('\lambda (nm)')
ylabel('\mu_a (mm^{-1})')

%% 

subplot(3,1,1)
plot(t,HbR_act)
 xlabel('t (s)')
 ylabel('HbR (\muM)')
 
 subplot(3,1,2)
plot(t,HbO_act)
 xlabel('t (s)')
 ylabel('HbO (\muM)')
  subplot(3,1,3)
plot(t,HbR_act+HbO_act)
 xlabel('t (s)')
 ylabel('HbT (\muM)')
 
 
 
 %% deltamu_a vs. lambda
 
 for nn=1:length(lambdaall)
lambda=lambdaall(nn); %nm
HbO=60*10^(-6); %M
HbR=40*10^(-6); %M

musp=CalculateMusp(lambda); %mm^(-1)
ext=GetExtinctions(lambda); % cm-1/(moles/liter)

mua=(ext(1)*HbO+ext(2)*HbR)*10^(-1); %mm^(-1)
% activation 
r_source=[0,0,0]; % source position, units mm
r_det=[30,0,0]; %detector position
S=1; % source amplitude 
voxelsize=1; % mm^3
Radius_activation=3;
r_act=[15 0 10];
%
VesselDilation_FunctionalForms; % we have t, rCBF, rCBV generated

rCMRO2=rCBF.^(1/3);
HbT_act=rCBV*(HbO+HbR);
rHbR=rCMRO2./rCBF.*rCBV;
HbR_act=rHbR*HbR;
HbO_act=HbT_act-HbR_act;

delta_mua=(ext(1)*HbO_act+ext(2)*HbR_act)*10^(-1)-mua;


delta_mua_all(nn,:)=delta_mua;


end
figure
[X,Y]=meshgrid(t,lambdaall); % double check if the axis is wrong
surf(X,Y,delta_mua_all,'EdgeColor','none')
xlabel('t (s)')
ylabel('\lambda (nm)')
zlabel('\Delta\mu_a')

set(gca,'fontsize', 12);
set(gcf, 'unit', 'inches');
   set(gcf, 'position',[1,1,4,3]);
   
   %%
   
   
   
   
   
   
   
   
   


