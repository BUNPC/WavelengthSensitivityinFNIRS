function [Phi]=CalculatePhi(r_source,r_det,musp,mua,delta_mua,r_act,Radius_activation,S, voxelsize)

c=3*10^11; %speed of light in the medium mm/s
n=1.33; %refractive index of tissue;
v=c/n; % speed of light in the medium. we probably don't need this but I kept it here.
D=v/(3*musp);% photon diffusion coefficient

Phi_0=S*Calculate2Pt(r_source+[0,0,1/musp],r_det,musp,mua);

xregion= [r_act(1)-Radius_activation:voxelsize:r_act(1)+Radius_activation];
yregion=[r_act(2)-Radius_activation:voxelsize:r_act(2)+Radius_activation];
zregion=[r_act(3)-Radius_activation:voxelsize:r_act(3)+Radius_activation];

Phi_pert=0;

for ii=1:length(xregion)
    for jj=1:length(yregion)
        for kk=1:length(zregion)
            r_now=[xregion(ii),yregion(jj),zregion(kk)];
            if norm(r_now-r_act)<=Radius_activation
                
                Phi_pert=Phi_pert-S*Calculate2Pt(r_source+[0,0,1/musp],r_now,musp,mua)*v*delta_mua/D*Calculate2Pt(r_now,r_det,musp,mua)*voxelsize;
                
            end
         
            
        end
    end
end
Phi_pert=Phi_pert/Phi_0;
Phi=Phi_0*exp(Phi_pert);


end