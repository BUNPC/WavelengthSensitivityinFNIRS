%% plot the figures 
clc
clear
lambdaall=650:10:900;

%% musp
figure
for ii=1:length(lambdaall)
muspall(ii)=CalculateMusp(lambdaall(ii)); 
end

plot(lambdaall,muspall)
xlabel('\lambda (nm)')
ylabel('\mu_s'' (mm^{-1})')
set(gcf, 'unit', 'inches')
   set(gcf, 'position',[1,1,4,3])


%%
figure
eall = GetExtinctions(lambdaall);
subplot(3,1,1)
plot(lambdaall,eall(:,1));
xlabel('\lambda (nm)')
ylabel('\epsilon_{HbO} (cm^{-1}M^{-1})')

subplot(3,1,2)
plot(lambdaall,eall(:,2));
xlabel('\lambda (nm)')
ylabel('\epsilon_{HbR} (cm^{-1}M^{-1})')

subplot(3,1,3)
plot(lambdaall,eall(:,3));
xlabel('\lambda (nm)')
ylabel('\epsilon_{H2O} (cm^{-1})')

%% mua
figure
 % cm-1/(moles/liter)
HbO=60*10^(-6); %M
HbR=40*10^(-6); %M
H2O=0.8; % the fraction
%mua=(ext(1)*HbO+ext(2)*HbR)*10^(-1); %mm^(-1)
for ii=1:length(lambdaall)
    ext=GetExtinctions(lambdaall(ii));
muaall(ii)=(ext(1)*HbO+ext(2)*HbR+ext(3)*H2O)*10^(-1); 
mua_HbO(ii)=ext(1)*HbO*0.1;
mua_HbR(ii)=ext(2)*HbR*0.1;
mua_H2O(ii)=ext(3)*H2O*0.1;

end

plot(lambdaall,muaall,'k')
xlabel('\lambda (nm)')
ylabel('\mu_a (mm^{-1})')




hold on
plot(lambdaall,mua_HbO,'r')

plot(lambdaall,mua_HbR,'b')

plot(lambdaall,mua_H2O,'c')

legend('total absorption','HbO','HbR','H_2O')
%% 

subplot(3,1,1)
plot(t,HbR_act)
 xlabel('t (s)')
 ylabel('HbR (\muM)')
 
 subplot(3,1,2)
plot(t,HbO_act)
 xlabel('t (s)')
 ylabel('HbO (\muM)')
  subplot(3,1,3)
plot(t,HbR_act+HbO_act)
 xlabel('t (s)')
 ylabel('HbT (\muM)')
 
 
 
 %% deltamu_a vs. lambda
 
 for nn=1:length(lambdaall)
lambda=lambdaall(nn); %nm
HbO=60*10^(-6); %M
HbR=40*10^(-6); %M

musp=CalculateMusp(lambda); %mm^(-1)
ext=GetExtinctions(lambda); % cm-1/(moles/liter)

mua=(ext(1)*HbO+ext(2)*HbR)*10^(-1); %mm^(-1)
% activation 
r_source=[0,0,0]; % source position, units mm
r_det=[30,0,0]; %detector position
S=1; % source amplitude 
voxelsize=1; % mm^3
Radius_activation=3;
r_act=[15 0 10];
%
Windkessel_OOT; % we have t, rCBF, rCBV generated



delta_mua=(ext(1)*HbO_act+ext(2)*HbR_act)*10^(-1)-mua;


delta_mua_all(nn,:)=delta_mua;


end
figure
[X,Y]=meshgrid(t,lambdaall); % double check if the axis is wrong
surf(X,Y,delta_mua_all,'EdgeColor','none')
xlabel('t (s)')
ylabel('\lambda (nm)')
zlabel('\Delta\mu_a')

%% all figures on the same curve

Windkessel_OOT;
HbO_change=HbO_act/HbO_act(1)-1;
HbT_change=rCBV/rCBV(1)-1;
HbR_change=HbR_act/HbR_act(1)-1;
CBF_change=rCBF/rCBF(1)-1;
plot(t,HbO_change/max(HbO_change),'r'); hold on
plot(t,HbT_change/max(HbT_change),'g');
plot(t,-HbR_change/max(-HbR_change),'b');

plot(t,CBF_change/max(CBF_change),'m');
xlim([0 18]);

xlabel('t (s)')
ylabel('Normalized Change (AU)');
legend('HbO','HbT','HbR','CBF')


