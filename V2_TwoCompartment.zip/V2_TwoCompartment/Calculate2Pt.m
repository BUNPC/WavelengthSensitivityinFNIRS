function Grsrd=Calculate2Pt(r_source,r_det,musp,mua)

%rs=r_source+[0,0,1/musp]; % location of the point source

rs=r_source;

rsi=[rs(1),rs(2),-rs(3)]-[0,0,4/(3*musp)]; % - the third component, location of the image source 

c=3*10^11; %speed of light in the medium mm/s
n=1.33; %refractive index of tissue;
v=c/n; % speed of light in the medium. we probably don't need this but I kept it here.
D=v/(3*musp);% photon diffusion coefficient

Grsrd=v/(4*pi*D)*(exp(-sqrt(3*musp*mua)*norm(rs-r_det))/norm(rs-r_det)- exp(-sqrt(3*musp*mua)*norm(rsi-r_det))/norm(rsi-r_det));


end