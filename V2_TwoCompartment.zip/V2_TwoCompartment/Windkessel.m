% Windkessel model %
%Mandeville, Joseph B., et al. "Evidence of a cerebrovascular postarteriole windkessel 
%with delayed compliance." Journal of Cerebral Blood Flow & Metabolism 19.6 (1999): 679-689.

%%


t=0:0.001:6;
deltaD=0.05;
sigma_D=1.83;
% P_in=60; %mmHg input blood pressure
% P_out=25; % mm Hg output blood pressure


%art
rD_art=1+t.^2*deltaD.*exp(-t.^2/sigma_D^2); %
 
rRAt=1./rD_art.^4;

RA0=0.65;% initial resistance of the arteriole
RW0=0.35;%initial resistance of the windkessel
P=1; % total drop of pressure
VW0=1.4; % initial volume of the windkessel compartment 1.4 s of transient time
FW0=1;

alphav=2;
betav=0.6;


RAt=RA0*rRAt;
FWt=zeros(1,length(t));
VWt=zeros(1,length(t));

FWt(1)=FW0;
VWt(1)=VW0;


A=VWt(1)/(FWt(1)*RW0)^(1/betav);


deltat=t(2)-t(1);
DeltaV=(FWt(1)-VWt(1)^(alphav+betav)/(A^betav*RW0*VW0^alphav))*deltat;

for ii=2:length(t)
    VWt(ii)=VWt(ii-1)+DeltaV;
    FWt(ii)=(P-VWt(ii)^betav/A^betav)/RAt(ii);
    DeltaV=(FWt(ii)-VWt(ii)^(alphav+betav)/(A^betav*RW0*VW0^alphav))*deltat;

     
    
end

% subplot(2,1,1)
% plot(t,VWt);xlabel('t(s)');ylabel('Volume of Windkessel (AU)')
% subplot(2,1,2)
% plot(t,FWt);xlabel('t(s)');ylabel('Flow (AU)')

%%
VAt=rD_art.^2;
VolumeFraction_art=0.25; % volume fraction of the arterial compartment
rCBV=VAt*VolumeFraction_art+VWt*(1-VolumeFraction_art)/VWt(1);
rCBF=FWt/FWt(1);
subplot(2,1,1)
 plot(t,rCBV);xlabel('t(s)');ylabel('rCBV (total)')
subplot(2,1,2)
 plot(t,rCBF);xlabel('t(s)');ylabel('rCBF')

%%



