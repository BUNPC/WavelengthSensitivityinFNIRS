% Windkessel model %
%Mandeville, Joseph B., et al. "Evidence of a cerebrovascular postarteriole windkessel 
%with delayed compliance." Journal of Cerebral Blood Flow & Metabolism 19.6 (1999): 679-689.

%%


t=0:0.1:15;

RA0=0.7;% initial resistance of the arterial compartment
RAmin=0.65;% minimum resistance of arterial compartment
sigmaRA=2.8;% width 
tRp=4; %time to peaks
rRAt=1-t.*(RA0-RAmin)/RA0.*exp(-(t-tRp).^2/sigmaRA^2);
%rD_art=1./(rRAt).^(0.25);

RW0=1-RA0;%initial resistance of the windkessel
P=1; % total drop of pressure
tau_w=8;% transient time

FW0=1;
VW0=FW0*tau_w; % initial volume of the windkessel compartment 1.4 s of transient time

alphav=2;
betav=0.65;


RAt=RA0*rRAt;
FWt=zeros(1,length(t));
VWt=zeros(1,length(t));

FWt(1)=FW0;
VWt(1)=VW0;


A=VWt(1)/(FWt(1)*RW0)^(1/betav);


deltat=t(2)-t(1);
DeltaV=(FWt(1)-VWt(1)^(alphav+betav)/(A^betav*RW0*VW0^alphav))*deltat;

for ii=2:length(t)
    VWt(ii)=VWt(ii-1)+DeltaV;
    FWt(ii)=(P-VWt(ii)^betav/A^betav)/RAt(ii);
    DeltaV=(FWt(ii)-VWt(ii)^(alphav+betav)/(A^betav*RW0*VW0^alphav))*deltat;

       
end


%%
VAt=1./rRAt.^(1/alphav);
VolumeFraction_art=0.65; % volume fraction of the arterial compartment
rCBV=VAt*VolumeFraction_art/VAt(1)+VWt*(1-VolumeFraction_art)/VWt(1);
rCBV1=VAt/VAt(1);
rCBV2=VWt/VWt(1);
rCBF=FWt/FWt(1);

VolumeFraction_t=VAt*VolumeFraction_art./(VAt*VolumeFraction_art/VAt(1)+VWt*(1-VolumeFraction_art)/VWt(1));

%subplot(2,1,1)
% hold on
%  plot(t,rCBV2-1,'b.');%xlabel('t(s)');ylabel('rCBV (total)')
%  plot(t,rCBV1-1,'r--'); % 
% %subplot(2,1,2)
%  plot(t,rCBF-1,'k--');%xlabel('t(s)');ylabel('rCBF')
%  
% legend('CBV_w','CBV_a','CBF')

%%
% You have two comparments: arteriole and windkessel
% you have CBV_a(t) and CBV_w(t)
% 

%%
SO2_art=1;
HbT=100*10^(-6); % the same as in art and vein
HbO_art=HbT*SO2_art.*rCBV1;
HbR_art=HbT*(1-SO2_art).*rCBV1;

SO2_vein=0.65;

HbO_vein=HbT*SO2_vein; %M
HbR_vein=HbT*(1-SO2_vein); %M


%% rCMRO2 
%rCMRO2=rCBF.^(1/3);
E0=0.4;% check
phi=0.2; % check constant related to capillary transient time
CBa=1;
xL=0:0.1:1; % I dont know what is this
CB0=CBa*(1-E0).^(1./rCBF(1)*xL);
Et=zeros(1,length(t));
CBt=zeros(length(t),length(xL));
DeltaCB=zeros(length(t),length(xL));


Et(1)=E0;
CBt(1,:)=CB0;
DeltaEt=deltat*(1-(1-E0).^(1./rCBF(1))-Et(1))*rCBF(1)/phi;
DeltaCB(1,:)=0;
for ii=2:length(t)
   Et(ii)=Et(ii-1)+DeltaEt;
    DeltaEt=deltat*(1-(1-E0).^(1./rCBF(ii))-Et(ii))*rCBF(ii)/phi;
    for jj=1:length(xL)
  CBt(ii,jj)=CBt(ii-1,jj)+DeltaCB(ii-1,jj);
  DeltaCB(ii,jj)=deltat*(CBa*(1-E0)^(1./rCBF(ii)*xL(jj))-CBt(ii,jj))*rCBF(ii)/phi;
    end
    
end

% E_f=1-(1-E0).^(1./rCBF);
% K1=E_f.*rCBF;
% rCMRO2=K1/K1(1);
% 
% CBtm=mean(CBt,2);
% rCMRO2=CBtm/CBtm(1);
% figure
% hold on
% %plot(t,Et/Et(1),'b');
% plot(t,rCMRO2,'k');
% 
% plot(t, rCBF,'r');
% legend('rCMRO2','rCBF')
%% deoxy
q=zeros(1,length(t));
q(1)=1;
fout=rCBV2.^((alphav+betav));
tau_w2=tau_w;
deltaq=(rCBF(1).*Et(1)/E0-fout(1)*q(1)./rCBV2(1))/tau_w2;
for ii=2:length(t)
    q(ii)=q(ii-1)+deltaq;
    deltaq=(rCBF(ii).*Et(ii)/E0-fout(ii)*q(ii)./rCBV2(ii))/tau_w2;
       
end
% figure
% plot(t,q,'b');
% hold on
% plot(t,rCBF,'r')


%%
HbO=60*10^(-6); %M
HbR=40*10^(-6); %M

HbT=(HbO+HbR)*rCBV;
HbR_act=HbR*q;
HbO_act=HbT-HbR*q;



% hold on
% plot(t, HbO/HbO(1),'k')
% 
% legend('rHbR','rCBF','rHbO')
% 
% xlabel('t (s)')
% ylabel('relative change')

%%
% figure
rHbR=q;

HbOFraction_t=HbO./HbT;
HbO_art=VolumeFraction_t.*HbT;%
HbO_wind=HbT-HbR-HbO_art;



% hold on
% plot(t,rHbR-1,'b');
% plot(t,HbO_art/HbO_art(1)-1,'r')
% plot(t,HbO_wind/HbO_wind(1)-1,'k')
% 
% % plot(t,rCBV1,'r');
% % plot(t,HbO)
% 
% xlabel('t');
% ylabel('relative change %');
% legend('HbR wind','HbO art','HbO wind')

%%

% % figure
% rHbR=q;
% 
% HbOFraction_t=HbO./HbT;
% HbO_art=VolumeFraction_t.*HbT;%
% HbO_wind=HbT-HbR-HbO_art;
% hold on
% plot(t,(rHbR-1)/min(rHbR-1),'b');
% plot(t,(HbO_art/HbO_art(1)-1)/max(HbO_art/HbO_art(1)-1),'r')
% plot(t,(HbO_wind/HbO_wind(1)-1)/max(HbO_wind/HbO_wind(1)-1),'k')

% plot(t,rCBV1,'r');
% plot(t,HbO)
% 
% xlabel('t');
% ylabel('normalized absolute relative change "%"');
% legend('HbR wind','HbO art','HbO wind')


% %rCMRO2=1;
% %rCMRO2=1+0.06*exp(-(t-5).^2/2^2);
% %rCMRO2=
% 
% HbT_vein_act=rCBV2*(HbO_vein+HbR_vein);
% rHbR_vein=rCMRO2./rCBF.*rCBV2;
% HbR_vein_act=rHbR_vein*HbR_vein;
% HbO_vein_act=HbT_vein_act-HbR_vein_act;
% %rHbO2=HbO_act2/HbO_act2(1);
% 
% HbO_act=HbO_vein_act*(1-VolumeFraction_art)+HbO_art*VolumeFraction_art;
% 
% HbR_act=HbR_vein_act*(1-VolumeFraction_art)+HbR_art*VolumeFraction_art;
% 
% %%
% figure
% plot(t,HbO_art/HbO_art(1));hold on
% plot(t,HbO_vein_act/HbO_vein_act(1),'r')
% plot(t,HbR_vein_act/HbR_vein_act(1),'k')
% 
% % subplot(2,1,1)
% % plot(t,HbO_act);
% % subplot(2,1,2)
% % plot(t,HbR_act)
% 
% %%
% figure
% plot(t,HbO_vein_act/HbO_vein_act(1))
% hold on
% plot(t,HbO_art/HbO_art(1),'r')
% hold on
% plot(t,HbR_vein_act/HbR_vein_act(1),'k');
% 
% legend('rHbO_{wind}','rHbO_{art}','rHbR_{wind}')


% plot(t,rCMRO2-1,'k.');
% 
% plot(t,rHbR-1,'c*');
% 
% plot(t,rHbO-1,'go');
% %plot(t,rCBV./rCBF-1,'*');
% xticks([-5 0 5 10])
% ylabel('relative change')
% xlabel('Time (s)')
% legend('CBV','CBF','CMRO2','HbR','HbO')
