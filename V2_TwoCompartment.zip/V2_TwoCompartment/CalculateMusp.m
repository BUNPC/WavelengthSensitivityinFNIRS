function musp=CalculateMusp(lambda)

musp=1*(lambda/800)^(-1.5);

end