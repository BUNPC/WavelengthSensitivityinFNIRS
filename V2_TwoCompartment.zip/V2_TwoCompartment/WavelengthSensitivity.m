%% calculate the response of CW 
clc
clear

musp=1; % mm^(-1)
mua=0.01; %mm^(-1)

r_source=[0,0,0]; % source position, units mm
r_det=[30,0,0]; %detector position

%r=[15,0,10];% location of the 

c=3*10^11; %speed of light in the medium mm/s
n=1.33; %refractive index of tissue;
v=c/n; % speed of light in the medium. we probably don't need this but I kept it here.
D=v/(3*musp);% photon diffusion coefficient

S=1; % source amplitude 


%% use method of images to calculate Phi_0

Phi_0=S*Calculate2Pt(r_source+[0,0,1/musp],r_det,musp,mua);

%% calculate Phi_pert
voxelsize=1; % mm^3
Radius_activation=3;
r_act=[15 0 10];
nn=0;
for delta_mua=0:0.00001:0.001% mm^(-1)
nn=nn+1;
xregion= [r_act(1)-Radius_activation:voxelsize:r_act(1)+Radius_activation];
yregion=[r_act(2)-Radius_activation:voxelsize:r_act(2)+Radius_activation];
zregion=[r_act(3)-Radius_activation:voxelsize:r_act(3)+Radius_activation];

Phi_pert=0;

for ii=1:length(xregion)
    for jj=1:length(yregion)
        for kk=1:length(zregion)
            r_now=[xregion(ii),yregion(jj),zregion(kk)];
            if norm(r_now-r_act)<=Radius_activation
                
                Phi_pert=Phi_pert-S*Calculate2Pt(r_source+[0,0,1/musp],r_now,musp,mua)*v*delta_mua/D*Calculate2Pt(r_now,r_det,musp,mua)*voxelsize;
                
            end
         
            
        end
    end
end
Phi_pert=Phi_pert/Phi_0;
Phi(nn)=Phi_0*exp(Phi_pert);


end

plot(0:0.00001:0.001,Phi);
xlabel('\delta\mu_a mm^{-1}')
ylabel('\Phi')

%Phi_pert=1/Phi_0*



